var express = require('express');
var router = express.Router();

/* GET users listing. */
// ~/users
router.get('/', function(req, res, next) {
  res.send('respond with a resource');
});

// ~/users/login
router.get('/login', (req, res, next) => {
  res.render('login')
});

module.exports = router;
